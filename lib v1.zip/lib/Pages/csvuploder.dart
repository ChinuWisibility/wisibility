import 'package:fluent_ui/fluent_ui.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'package:csv/csv.dart';
import 'package:wisibility/Pages/csv/csvAnalysis.dart'; // or wherever you use your analyzeCsv


List<List<dynamic>> csvTable = [];
const List<String> mandatoryFields = [
  'EmployeeID',
  'DisplayName',
  'Title',
  'Department',
  'EndDate',
  'Status',
  'Email',
  'PhoneNumber',
  'Location',
  'Groups',
  'ManagerID',
];

class CsvUploader extends StatefulWidget {
  final void Function(Map<String, dynamic> stats, Map<String, List<String>> details) onResultGenerated;

  const CsvUploader({super.key, required this.onResultGenerated});

  @override
  State<CsvUploader> createState() => _CsvUploaderState();
}

class _CsvUploaderState extends State<CsvUploader> {
  List<String> headers = [];

  Map<String, String?> mappedFields = {};

  Future<void> pickCsvFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv'],
    );
    final path = result?.files.single.path;
    if (path != null) {
      final content = await File(path).readAsString();
      final table = CsvToListConverter().convert(content);
      if (table.isNotEmpty) {
        setState(() {
          headers = table.first.map((e) => e.toString().trim()).toList();
          csvTable = table;
          mappedFields = {
            for (final field in mandatoryFields)
              field: headers.firstWhere(
                    (h) => h.toLowerCase() == field.toLowerCase(),
                orElse: () => "null",
              )
          };
        });
      }
    }
  }

  void onBeginPressed() {
    final unmapped = mappedFields.entries
        .where((e) => e.value == null)
        .map((e) => e.key)
        .toList();

    if (unmapped.isNotEmpty) {
      showDialog(
        context: context,
        builder: (_) => ContentDialog(
          title: const Text('Missing mappings'),
          content: Text('Please map these required fields:\n${unmapped.join(', ')}'),
          actions: [
            Button(child: const Text('OK'), onPressed: () => Navigator.pop(context)),
          ],
        ),
      );
      return;
    }

    final result = analyzeCsv(csvTable, mappedFields);
    widget.onResultGenerated(
      Map<String, dynamic>.from(result['stats'] as Map),
      Map<String, List<String>>.from(
        (result['details'] as Map).map(
              (k, v) => MapEntry(
            k as String,
            v is List
                ? v.expand((e) => e is List ? e.map((ee) => ee.toString()) : [e.toString()]).toList()
                : [],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldPage(
      header: const PageHeader(title: Text('CSV Header Mapping')),
      content: Container(
        width: double.infinity,
        height: double.infinity,
        padding: const EdgeInsets.all(18),
        color: Colors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Button(
              child: const Text('Upload CSV'),
              onPressed: pickCsvFile,
            ),
            const SizedBox(height: 20),
            if (headers.isNotEmpty)
              Expanded(
                child: ListView(
                  children: [
                    ...mandatoryFields.map((field) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: _DropdownColumn(
                          label: field,
                          placeholder: field,
                          headers: headers,
                          value: mappedFields[field],
                          onChanged: (v) => setState(() => mappedFields[field] = v),
                        ),
                      );
                    }).toList(),
                    const SizedBox(height: 20),
                    Button(
                      child: const Text('Begin'),
                      onPressed: onBeginPressed,
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _DropdownColumn extends StatelessWidget {
  final String label;
  final String placeholder;
  final List<String> headers;
  final String? value;
  final ValueChanged<String?> onChanged;

  const _DropdownColumn({
    super.key,
    required this.label,
    required this.placeholder,
    required this.headers,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("Please select the $label:"),
        const SizedBox(height: 6),
        ComboBox<String>(
          placeholder: Text(placeholder),
          items: headers
              .map((header) => ComboBoxItem<String>(
            value: header,
            child: Text(header),
          ))
              .toList(),
          value: value,
          onChanged: onChanged,
        ),
      ],
    );
  }
}
